clear all; close all;

files = dir('*.tif');
names = [];
for i=1:length(files),
   names = [names; files(i).name];
end;
figure;
colormap(gray(256));
allim = [];
for i=1:size(names,1)
   im = imread(names(i,:), 'tif');
   imagesc(im);
%   disp('press any key');
%   pause;
   imvec = reshape(im', prod(size(im)), 1);
   allim = [allim, imvec];
end;

allim = double(allim);
allmean = mean(allim')';
N = size(allim,1);
M = size(allim,2);
demean = allim - (allmean*ones(1,M));
allcov = demean'*demean/M;

%[v,d] = eig(allcov);
[v,d,u] = svd(allcov);

ef = demean*v;

for i=1:M,
   face = ef(:,i);
   fimg = reshape(face, 100,100)';
   imagesc(fimg);
   title(sprintf('Eigenface %d',i));
   pause;
end;

% project original images onto eigenvectors
proj = (demean' * ef)';
forplot = proj(1:3, :);
figure;
plot3(forplot(1,:),forplot(2,:),forplot(3,:),'x');
hold on; rotate3d; grid;
plot3(forplot(1,:),forplot(2,:),forplot(3,:));

% reconstruct projected faces by summing relevant eigenvectors
relev = ef(:,1:3);
recon = relev * forplot;

figure;
colormap(gray(256));
for i=1:M,
   face = recon(:,i);
   fimg = reshape(face, 100,100)';
   imagesc(fimg);
   title(sprintf('Reconstructed face %d using first 3 PCs',i));
   pause;
end;

% finally calculate residuals

resid = sum(demean.*demean) - sum(recon.*recon);
figure;
plot(resid);
title('residuals of images');
